<?php

namespace Drupal\bootstrap\Plugin\Provider;

/**
 * Class InvalidCdnUrlException.
 */
class InvalidCdnUrlException extends \RuntimeException {}
